# M&M Review Studio

Streamlit 기반의 M&M(Morbidity & Mortality) Conference 교육용 웹사이트 프로토타입입니다.

## GitHub Codespaces에서 실행하기

1. GitHub 저장소에 이 프로젝트 파일을 업로드합니다.
2. 저장소의 **Code → Codespaces → Create codespace on main**을 선택합니다.
3. Codespaces가 열리면 **Terminal → New Terminal**을 선택합니다.
4. 다음 명령어를 실행합니다.

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py --server.address 0.0.0.0
```

5. Codespaces 하단의 **Ports** 탭에서 `8501` 포트를 찾아 **Open in Browser**를 누릅니다.

## 폴더 구조

- `app.py`: 앱 실행, 페이지 이동, MONOCHROME 테마
- `assets/styles.css`: 전체 디자인과 애니메이션
- `components/hero.py`: 스크롤에 반응하는 메인 문장
- `data/cases.json`: 교육용 가상 사례
- `utils/case_loader.py`: 사례 데이터 읽기
- `views/`: 메인, 사례 목록, 사례 분석, 퀴즈 화면
- `.streamlit/config.toml`: Streamlit 기본 설정

## 배포

GitHub에 변경 사항을 push한 뒤 https://share.streamlit.io 에서 저장소를 연결하고 `app.py`를 실행 파일로 지정합니다.

## 주의

현재 사례는 모두 교육용 합성 사례입니다. 실제 환자 기록, 환자 식별 정보, 병원 내부 자료를 업로드하지 마세요. 이 앱은 임상 의사결정이나 환자 진료를 위한 도구가 아닙니다.
