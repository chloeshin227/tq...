from pathlib import Path

import streamlit as st


st.set_page_config(
    page_title="M&M Review Studio",
    page_icon="◌",
    layout="wide",
    initial_sidebar_state="collapsed",
)

ROOT = Path(__file__).parent
BASE_CSS = (ROOT / "assets" / "styles.css").read_text(encoding="utf-8")

if "monochrome" not in st.session_state:
    st.session_state.monochrome = False

if st.session_state.monochrome:
    theme_vars = """
    :root {
      --app-bg: #21232E;
      --ink: #F4F5F8;
      --muted: #A7ABBA;
      --accent: #105BFF;
      --accent-soft: #FE8500;
      --glass: rgba(255,255,255,.065);
      --line: rgba(255,255,255,.13);
      --glass-shadow: 0 24px 70px rgba(0,0,0,.24);
      --app-glow:
        radial-gradient(ellipse at 78% 4%, rgba(16,91,255,.20), transparent 34%),
        radial-gradient(ellipse at 8% 72%, rgba(254,133,0,.055), transparent 28%);
    }
    """
else:
    theme_vars = """
    :root {
      --app-bg: #E9E5D6;
      --ink: #222526;
      --muted: #737A7B;
      --accent: #2589D8;
      --accent-soft: #FE6574;
      --glass: rgba(255,255,255,.42);
      --line: rgba(34,37,38,.10);
      --glass-shadow: 0 22px 62px rgba(53,58,54,.08);
      --app-glow:
        radial-gradient(ellipse at 78% 0%, rgba(37,137,216,.13), transparent 35%),
        radial-gradient(ellipse at 8% 72%, rgba(254,101,116,.08), transparent 30%);
    }
    """

st.html(f"<style>{BASE_CSS}\n{theme_vars}</style>")

# Define pages once. The custom navigation below replaces Streamlit's default menu.
home_page = st.Page("views/home.py", title="Overview", url_path="overview", default=True)
cases_page = st.Page("views/case_library.py", title="Case Library", url_path="cases")
review_page = st.Page("views/case_review.py", title="Review Room", url_path="review")
quiz_page = st.Page("views/learning_check.py", title="Knowledge Check", url_path="knowledge-check")
current_page = st.navigation(
    [home_page, cases_page, review_page, quiz_page],
    position="hidden",
)

# Global top navigation
nav = st.columns([2.2, 0.9, 0.9, 1.05, 1.05, 1.35], vertical_alignment="center")
with nav[0]:
    st.markdown(
        '<div class="top-brand">M&amp;M <span>REVIEW STUDIO</span></div>',
        unsafe_allow_html=True,
    )
with nav[1]:
    st.page_link(home_page, label="OVERVIEW")
with nav[2]:
    st.page_link(cases_page, label="CASES")
with nav[3]:
    st.page_link(review_page, label="REVIEW ROOM")
with nav[4]:
    st.page_link(quiz_page, label="KNOWLEDGE")
with nav[5]:
    toggle_label = "MONOCHROME · ON" if st.session_state.monochrome else "MONOCHROME · OFF"
    if st.button(toggle_label, key="theme_toggle", use_container_width=True):
        st.session_state.monochrome = not st.session_state.monochrome
        st.rerun()

st.markdown('<div style="height:1px;background:var(--line);margin:1rem 0 2rem;"></div>', unsafe_allow_html=True)
current_page.run()
