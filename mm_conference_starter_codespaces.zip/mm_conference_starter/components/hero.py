import streamlit as st


@st.cache_resource
def _register_scroll_story():
    """Register once: scroll observation is handled in the browser, not by Python reruns."""
    html = """
    <section class="mm-story" aria-label="M and M conference introduction">
      <div class="mm-story__meta">
        <span>M&amp;M REVIEW STUDIO</span>
        <span>EDUCATION · SYSTEMS · SAFETY</span>
      </div>

      <div class="mm-story__line" data-scroll-line>
        Every outcome leaves<br><em>a question.</em>
      </div>
      <div class="mm-story__line" data-scroll-line>
        Which signals<br><em>were missed?</em>
      </div>
      <div class="mm-story__line" data-scroll-line>
        Where did the<br><em>system fail?</em>
      </div>
      <div class="mm-story__line" data-scroll-line>
        Not blame.<br><em>Better systems.</em>
      </div>

      <div class="mm-story__footer">
        <span>MORBIDITY &amp; MORTALITY CONFERENCE</span>
        <span>SCROLL TO REFLECT ↓</span>
      </div>
    </section>
    """

    css = """
    /* Kept in the component so the scroll story is self-contained. */
    .mm-story { box-sizing: border-box; width: 100%; }
    .mm-story * { box-sizing: border-box; }
    """

    js = """
    export default function({ parentElement }) {
      const lines = parentElement.querySelectorAll('[data-scroll-line]');
      if (!lines.length) return;

      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          entry.target.classList.toggle('is-active', entry.isIntersecting);
        });
      }, {
        root: null,
        rootMargin: '-43% 0px -43% 0px',
        threshold: 0
      });

      lines.forEach((line) => observer.observe(line));
      return () => observer.disconnect();
    }
    """

    return st.components.v2.component(
        name="mm_scroll_story",
        html=html,
        css=css,
        js=js,
        isolate_styles=False,
    )


def render_hero():
    component = _register_scroll_story()
    component()
