import streamlit as st

from utils.case_loader import get_case, load_cases


cases = load_cases()
case_id = st.session_state.get("active_case_id", cases[0]["id"])
case = get_case(case_id) or cases[0]

st.markdown('<div class="eyebrow">02 / STRUCTURED CASE REVIEW</div>', unsafe_allow_html=True)
st.markdown(f'<div class="section-heading">{case["title"]}</div>', unsafe_allow_html=True)
st.markdown(
    f'<span class="case-tag">{case["id"]}</span> '
    f'<span class="case-tag">{case["specialty"]}</span> '
    f'<span class="case-tag">{case["case_type"]}</span>',
    unsafe_allow_html=True,
)
st.write("")
st.info("Synthetic educational scenario. No real patient record or identifiable patient information is used.")
st.markdown("### Case brief")
st.write(case["summary"])

st.markdown("### 01 — Timeline reconstruction")
for event in case["timeline"]:
    with st.container(border=True):
        st.markdown(f'<div class="timeline-time">{event["time"]}</div>', unsafe_allow_html=True)
        st.markdown(f"#### {event['title']}")
        st.write(event["detail"])

left, right = st.columns(2, gap="large")
with left:
    st.markdown("### 02 — Contributing conditions")
    for item in case["contributors"]:
        st.markdown(f"- {item}")
with right:
    st.markdown("### 03 — Questions for the room")
    for item in case["system_questions"]:
        st.markdown(f"- {item}")

st.markdown("### 04 — Learning objectives")
for objective in case["learning_objectives"]:
    st.markdown(f"- {objective}")

with st.container(border=True):
    st.markdown('<div class="eyebrow">KEY TAKEAWAY</div>', unsafe_allow_html=True)
    st.write(case["takeaway"])

st.page_link("views/learning_check.py", label="CONTINUE TO KNOWLEDGE CHECK →")
