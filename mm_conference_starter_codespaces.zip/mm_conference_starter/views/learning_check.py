import streamlit as st

from utils.case_loader import get_case, load_cases


cases = load_cases()
case_id = st.session_state.get("active_case_id", cases[0]["id"])
case = get_case(case_id) or cases[0]
quiz = case["quiz"]

st.markdown('<div class="eyebrow">03 / KNOWLEDGE CHECK</div>', unsafe_allow_html=True)
st.markdown('<div class="section-heading">Think beyond<br>the final outcome.</div>', unsafe_allow_html=True)
st.caption(f"{case['id']} · {case['title']}")

with st.form("knowledge_check_form"):
    answer = st.radio(quiz["question"], quiz["options"], index=None)
    submitted = st.form_submit_button("SUBMIT ANSWER")

if submitted:
    if answer is None:
        st.warning("Choose an answer before submitting.")
    else:
        selected_index = quiz["options"].index(answer)
        if selected_index == quiz["answer_index"]:
            st.success("Correct. You identified the system-level issue emphasized in this case.")
        else:
            st.warning("Not quite. Revisit the timeline and contributing conditions, then try to explain the process failure.")
        with st.container(border=True):
            st.markdown('<div class="eyebrow">FACILITATOR NOTE</div>', unsafe_allow_html=True)
            st.write(quiz["explanation"])

st.write("")
st.markdown("### Your own review note")
reflection = st.text_area(
    "What is one system-level change you would propose?",
    placeholder="Describe one practical change and how you would evaluate whether it worked...",
    height=130,
)
if st.button("SAVE NOTE IN THIS SESSION"):
    if reflection.strip():
        st.session_state[f"reflection_{case_id}"] = reflection.strip()
        st.success("Saved for this browser session. A permanent account/database is not connected yet.")
    else:
        st.warning("Write a short reflection first.")
