import streamlit as st

from components.hero import render_hero
from utils.case_loader import load_cases


render_hero()

cases = load_cases()

st.markdown('<div class="eyebrow">A LEARNING SPACE FOR FUTURE CLINICIANS</div>', unsafe_allow_html=True)
st.markdown('<div class="section-heading">Review the outcome.<br>Improve what comes next.</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="section-copy">A case-based learning environment inspired by Morbidity &amp; Mortality Conference. '
    'Explore fictional cases, reconstruct the timeline, examine system factors, and test your understanding.</div>',
    unsafe_allow_html=True,
)

st.write("")
metric_cols = st.columns(3)
metrics = [
    (f"{len(cases):02d}", "SYNTHETIC CASES"),
    ("04", "REVIEW STAGES"),
    ("01", "CORE PRINCIPLE · NO BLAME"),
]
for col, (number, label) in zip(metric_cols, metrics):
    with col:
        with st.container(border=True):
            st.markdown(f'<div class="metric-number">{number}</div><div class="metric-label">{label}</div>', unsafe_allow_html=True)

st.write("")
left, right = st.columns([1.25, 1], gap="large")
with left:
    st.markdown('<div class="eyebrow">THE REVIEW METHOD</div>', unsafe_allow_html=True)
    st.markdown("### From outcome to understanding")
    st.markdown(
        "1. **Reconstruct** — establish what happened and when.\n\n"
        "2. **Interpret** — identify information, decisions, and contributing conditions.\n\n"
        "3. **Improve** — propose a system-level change that can be evaluated."
    )
with right:
    with st.container(border=True):
        st.markdown('<div class="eyebrow">START HERE · 01</div>', unsafe_allow_html=True)
        st.markdown("### Enter the case library")
        st.write("Choose a fictional case and begin a structured review.")
        st.page_link("views/case_library.py", label="EXPLORE CASES →")

st.write("")
st.caption("Educational prototype · All cases in this build are fictional and synthetic. Not for clinical decision-making.")
