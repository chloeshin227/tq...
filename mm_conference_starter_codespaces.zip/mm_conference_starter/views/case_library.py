import streamlit as st

from utils.case_loader import load_cases


st.markdown('<div class="eyebrow">01 / CASE ARCHIVE</div>', unsafe_allow_html=True)
st.markdown('<div class="section-heading">The case library.</div>', unsafe_allow_html=True)
st.markdown('<div class="section-copy">Each case is fictional and designed to practice structured, non-blaming review.</div>', unsafe_allow_html=True)

cases = load_cases()
query = st.text_input("SEARCH CASES", placeholder="Search by title, specialty, or topic...")
all_specialties = sorted({case["specialty"] for case in cases})
specialty = st.selectbox("SPECIALTY", ["All specialties", *all_specialties])

filtered = []
for case in cases:
    searchable = f"{case['title']} {case['specialty']} {case['topic']}".lower()
    matches_query = query.lower() in searchable
    matches_specialty = specialty == "All specialties" or case["specialty"] == specialty
    if matches_query and matches_specialty:
        filtered.append(case)

st.write("")
if not filtered:
    st.info("No cases match those filters.")

for case in filtered:
    with st.container(border=True):
        meta_left, meta_right = st.columns([3, 1])
        with meta_left:
            st.markdown(f'<span class="case-tag">{case["id"]}</span> <span class="case-tag">{case["level"]}</span>', unsafe_allow_html=True)
            st.markdown(f"### {case['title']}")
            st.write(case["summary"])
            st.caption(f"{case['specialty']}  ·  {case['topic']}")
        with meta_right:
            st.write("")
            if st.button("OPEN CASE ↗", key=f"open_{case['id']}", use_container_width=True):
                st.session_state.active_case_id = case["id"]
                st.switch_page("views/case_review.py")
